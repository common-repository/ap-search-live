<?php
/**
 * Plugin Name: AP Search Live
 * Plugin URI:
 * Description: A search live plugin to order by category or by custom field
 * Version: 1.0
 * Author: Alfani Pellegrini
 * Author URI: 
 * Text Domain: ap-search-live
 * Domain Path: 
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AP_SEARCH_LIVE_PLUGIN_VERSION', '1.0' );
define( 'AP_SEARCH_LIVE_PLUGIN', 'ap-search-live' );
define( 'AP_SEARCH_LIVE_PLUGIN_DOMAIN', 'ap-search-live' );
define( 'AP_SEARCH_LIVE_FILE', __FILE__ );
if ( !defined( 'AP_SEARCH_LIVE_LOG' ) ) {
	define( 'AP_SEARCH_LIVE_LOG', false );
}
if ( !defined( 'AP_SEARCH_LIVE_DEBUG' ) ) {
	define( 'AP_SEARCH_LIVE_DEBUG', false );
}
define( 'AP_SEARCH_LIVE_CORE_DIR', plugin_dir_path( __FILE__ ) );
define( 'AP_SEARCH_LIVE_CORE_LIB', AP_SEARCH_LIVE_CORE_DIR . 'core' );
define( 'AP_SEARCH_LIVE_ADMIN_LIB', AP_SEARCH_LIVE_CORE_DIR . 'admin' );
define( 'AP_SEARCH_LIVE_VIEWS_LIB', AP_SEARCH_LIVE_CORE_DIR . 'views' );
define( 'AP_SEARCH_LIVE_PLUGIN_URL', plugins_url( 'ap-search-live' ) );
require_once AP_SEARCH_LIVE_CORE_LIB . '/class-ap-search-live.php';
