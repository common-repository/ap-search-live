<?php


if ( !defined( 'ABSPATH' ) ) {
	exit;
}

class AP_Search_Live_Thumbnail {

	const THUMBNAIL                 = 'ap-search-live-thumbnail';
	const THUMBNAIL_WIDTH           = 'ap-search-live-thumbnail-width';
	const THUMBNAIL_HEIGHT          = 'ap-search-live-thumbnail-height';
	const THUMBNAIL_DEFAULT_WIDTH   = 64;
	const THUMBNAIL_DEFAULT_HEIGHT  = 64;
	const THUMBNAIL_MAX_DIM         = 1024;
	const THUMBNAIL_CROP            = 'ap-search-live-thumbnail-crop';
	const THUMBNAIL_DEFAULT_CROP    = true;
	const THUMBNAIL_USE_PLACEHOLDER = 'ap-search-live-thumbnail-placeholder';
	const THUMBNAIL_USE_PLACEHOLDER_DEFAULT = true;

	public static function init() {
		add_action( 'after_setup_theme', array( __CLASS__, 'after_setup_theme' ) );
		add_filter( 'image_downsize', array( __CLASS__, 'image_downsize' ), 10, 3 );
	}

	public static function after_setup_theme() {
		// add the thumbnail image size
		$thumbnail_width   = self::THUMBNAIL_DEFAULT_WIDTH;
		$thumbnail_height  = self::THUMBNAIL_DEFAULT_HEIGHT;
		$thumbnail_crop    = self::THUMBNAIL_DEFAULT_CROP;
		add_image_size( self::thumbnail_size_name(), intval( $thumbnail_width ), intval( $thumbnail_height ), $thumbnail_crop );
	}

	public static function thumbnail_size_name() {
		$thumbnail_width   = self::THUMBNAIL_DEFAULT_WIDTH;
		$thumbnail_height  = self::THUMBNAIL_DEFAULT_HEIGHT;
		return sprintf( self::THUMBNAIL . '-%dx%d', intval( $thumbnail_width ), intval( $thumbnail_height ) );
	}

	
	public static function image_downsize( $foo, $id, $size ) {

		$result = false;

		if ( $size == self::thumbnail_size_name() ) {

			// really make sure we have the size defined as we're going to need it
			self::after_setup_theme();

			require_once ABSPATH . '/wp-admin/includes/image.php';

			if ( !empty( $size ) && wp_attachment_is_image( $id ) ) {
				$regenerate = false;
				// Do we have the appropriate size? 
				if ( $intermediate = image_get_intermediate_size( $id, $size ) ) {
					$img_url = $intermediate['url'];
					if ( empty( $img_url ) && !empty( $intermediate['file'] ) ) {
						$original_file_url = wp_get_attachment_url( $id );
						if ( !empty( $original_file_url ) ) {
							$img_url = path_join( dirname( $original_file_url ), $intermediate['file'] );
						}
					}
					$width = $intermediate['width'];
					$height = $intermediate['height'];
					$is_intermediate = true;
				}

				if ( isset( $img_url ) ) {
					// adjust for editor or theme
					list( $width, $height ) = image_constrain_size_for_editor( $width, $height, $size );
					$result = array( $img_url, $width, $height, $is_intermediate );

					// check the dimensions and ratios, used below
					
					$thumbnail_width   = self::THUMBNAIL_DEFAULT_WIDTH;
					$thumbnail_height  = self::THUMBNAIL_DEFAULT_HEIGHT;
					$thumbnail_crop    = self::THUMBNAIL_DEFAULT_CROP;

					switch( $thumbnail_crop ) {
						// crop => dimensions must match
						case true :
							if ( ( $width != $thumbnail_width ) || ( $height != $thumbnail_height ) ) {
								$regenerate = true;
							}
							break;
						// don't crop => ratios must match
						case false :
							$meta = wp_get_attachment_metadata( $id );
							$r1 = round( floatval( $width ) / floatval( $height > 0 ? $height : 1 ), 3 );
							$r2 = round( floatval( $meta['width'] ) / floatval( $meta['height'] > 0 ? $meta['height'] : 1 ), 3 );
							if ( $r2 == 0 ) {
								$r2 = 0.001;
							}
							// regenerate if the ratios differ over 25%
							if ( abs( $r1 / $r2 - 1 ) > 0.25 ) {
								$regenerate = true;
							}
							break;
					}
				}

				
				if ( !$result || $regenerate ) {
					$meta = wp_get_attachment_metadata( $id );
					$upload_dir = wp_upload_dir();
					$img_file = get_attached_file( $id );
					$new_meta = wp_generate_attachment_metadata( $id, $img_file );
					wp_update_attachment_metadata( $id, $new_meta );
					// now try again
					if ( $intermediate = image_get_intermediate_size( $id, $size ) ) {
						$img_url = $intermediate['url'];
						if ( empty( $img_url ) && !empty( $intermediate['file'] ) ) {
							$original_file_url = wp_get_attachment_url( $id );
							if ( !empty( $original_file_url ) ) {
								$img_url = path_join( dirname( $original_file_url ), $intermediate['file'] );
							}
						}
						$width = $intermediate['width'];
						$height = $intermediate['height'];
						$is_intermediate = true;
					}
					if ( isset( $img_url ) ) {
						// adjust ...
						list( $width, $height ) = image_constrain_size_for_editor( $width, $height, $size );
						$result = array( $img_url, $width, $height, $is_intermediate );
					}
				}
			}
		}
		return $result;
	}

	public static function get_placeholder_thumbnail() {
		$result = null;
		$thumbnail_use_placeholder = self::THUMBNAIL_USE_PLACEHOLDER_DEFAULT;
		if ( $thumbnail_use_placeholder ) {
			$thumbnail_url = AP_SEARCH_LIVE_PLUGIN_URL . '/images/default.jpg'; 
			$thumbnail_width   = self::THUMBNAIL_DEFAULT_WIDTH;
			$thumbnail_height  = self::THUMBNAIL_DEFAULT_HEIGHT;
			$result = array( $thumbnail_url, $thumbnail_width, $thumbnail_height );
		}
		return $result;
	}
}
AP_Search_Live_Thumbnail::init();
