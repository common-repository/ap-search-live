=== AP Search Live ===
Contributors: alfapelle 
Tags: search, live, category,custom field
Requires at least: 4.7.1
Tested up to: 4.7.1
Stable tag: -

A search live plugin to order by category or by custom field


== Installation ==

Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.

