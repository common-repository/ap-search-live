<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

class AP_Search_Live_Service {

	const SEARCH_TOKEN  = 'ap-search-live';
	const SEARCH_QUERY  = 'ap-search-live-query';

	const LIMIT         = 'limit';
	const DEFAULT_LIMIT = 8;

	const DEFAULT_TITLE   = true;
	const DEFAULT_EXCERPT = true;
	const DEFAULT_CONTENT = true;

	const ORDER            = 'order';
	const DEFAULT_ORDER    = 'DESC';
	const ORDER_BY         = 'order_by';
	const DEFAULT_ORDER_BY = 'date';

	const DEFAULT_DESCRIPTION = true;

	const THUMBNAILS          = 'thumbnails';
	const DEFAULT_THUMBNAILS  = true;

	const CACHE_LIFETIME     = 300; // in seconds, 5 minutes
	const POST_CACHE_GROUP   = 'ixslp';
	const RESULT_CACHE_GROUP = 'ixslr';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'wp_init' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'wp_enqueue_scripts' ) );
		add_action( 'wp_ajax_ap_search_live', array( __CLASS__, 'wp_ajax_ap_search_live' ) );
		add_action( 'wp_ajax_nopriv_ap_search_live', array( __CLASS__, 'wp_ajax_ap_search_live' ));
	}

	public static function wp_ajax_ap_search_live() {
		ob_start();
		$results = AP_Search_Live_Service::request_results();
		$ob = ob_get_clean();
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG && $ob ) {
			error_log( $ob );
		}
		echo json_encode( $results );
		exit;
	}

	public static function wp_enqueue_scripts() {
		wp_register_script( 'typewatch', AP_SEARCH_LIVE_DEBUG ? AP_SEARCH_LIVE_PLUGIN_URL . '/js/jquery.typewatch.js' : AP_SEARCH_LIVE_PLUGIN_URL . '/js/jquery.typewatch.min.js', array( 'jquery' ), AP_SEARCH_LIVE_PLUGIN_VERSION, true );
		wp_register_script( 'ap-search-live', AP_SEARCH_LIVE_DEBUG ? AP_SEARCH_LIVE_PLUGIN_URL . '/js/ap-search-live.js' :  AP_SEARCH_LIVE_PLUGIN_URL . '/js/ap-search-live.min.js', array( 'jquery', 'typewatch' ),  AP_SEARCH_LIVE_PLUGIN_VERSION, true );
		wp_register_style( 'ap-search-live', AP_SEARCH_LIVE_PLUGIN_URL . '/css/ap-search-live.css', array(),  AP_SEARCH_LIVE_PLUGIN_VERSION );
		wp_localize_script( 'ap-search-live', 'searchLiveInfo', array(
			'blogURL'=>get_bloginfo('url'),
			'queryValue'=>get_search_query()
			));
	}

	public static function wp_init() {
		$options = AP_Search_Live::get_options();
		add_action( 'pre_get_posts', array( __CLASS__, 'pre_get_posts' ) );
		add_filter( 'posts_search', array( __CLASS__, 'posts_search' ), 10 , 2 );
	}

	public static function pre_get_posts( $wp_query ) {
		if ( self::process_search_query( $wp_query ) ) {
			if ( !isset( $_REQUEST[self::SEARCH_QUERY] ) ) {
				$_REQUEST[self::SEARCH_QUERY] = $_REQUEST['s'];
			}
			$post_ids = self::get_post_ids_for_request();
			if ( !empty( $post_ids ) ) {
				$wp_query->set( 'post__in', $post_ids );
			}
		}
	}

	public static function posts_search( $search, $wp_query ) {
		if ( self::process_search_query( $wp_query ) ) {
			$search = '';
		}
		return $search;
	}

	private static function process_search_query( &$wp_query ) {
		$result = false;
		if ( $wp_query->is_search() ) {		
			$result = true;
		}
		return $result;
	}


	private static function get_request_parameters() {

		$title       = self::DEFAULT_TITLE;
		$excerpt     = self::DEFAULT_EXCERPT;
		$content     = self::DEFAULT_CONTENT;
		$limit       = self::DEFAULT_LIMIT;
		$numberposts = intval( apply_filters( 'ap_search_live_limit', $limit ) );
		$order       = self::DEFAULT_ORDER;
		$order_by    = self::DEFAULT_ORDER_BY;
		$search_query = preg_replace( '/[^\p{L}\p{N}]++/u', ' ', $_REQUEST[self::SEARCH_QUERY] );
		$search_query = trim( preg_replace( '/\s+/', ' ', $search_query ) );

		return array(
			'title'        => $title,
			'excerpt'      => $excerpt,
			'content'      => $content,
			'limit'        => $limit,
			'numberposts'  => $numberposts,
			'order'        => $order,
			'order_by'     => $order_by,
			'search_query' => $search_query
		);
	}

	public static function get_post_ids_for_request() {

		global $wpdb;

		$parameters = self::get_request_parameters();
		extract( $parameters );

		$search_terms = explode( ' ', $search_query );

		$cache_key = self::get_cache_key( array(
			'title'        => $title,
			'excerpt'      => $excerpt,
			'content'      => $content,
			'limit'        => $numberposts,
			'order'        => $order,
			'order_by'     => $order_by,
			'search_query' => $search_query
		) );

		$post_ids = wp_cache_get( $cache_key, self::POST_CACHE_GROUP, true );
		if ( $post_ids !== false ) {
			return $post_ids;
		}

		$options = AP_Search_Live::get_options();
		$conj = array();

		foreach ( $search_terms as $search_term ) {
			$args   = array();
			$params = array();

			$like = '%' . $wpdb->esc_like( $search_term ) . '%';

			if ( $title ) {
				$args[] = ' post_title LIKE %s ';
				$params[] = $like;
			}
			if ( $excerpt ) {
				$args[] = ' post_excerpt LIKE %s ';
				$params[] = $like;
			}
			if ( $content ) {
				$args[] = ' post_content LIKE %s ';
				$params[] = $like;
			}

			if ( !empty( $args ) ) {
				$conj[] = $wpdb->prepare( 
					sprintf( ' ( %s ) ', implode( ' OR ', $args ) ), $params );
			}

		}

		$conditions = implode( ' AND ', $conj );
		$include = array();
	
		$query =  sprintf( "SELECT ID FROM $wpdb->posts WHERE ( post_status = 'publish' AND post_type = 'post' ) AND %s", $conditions );
		
		$results = $wpdb->get_results( $query );
		if ( !empty( $results ) && is_array( $results ) ) {
			foreach ( $results as $result ) {
				$include[] = intval( $result->ID );
			}
		}
		unset( $results );
	
		$cached = wp_cache_set( $cache_key, $include, self::POST_CACHE_GROUP, self::get_cache_lifetime() );

		return $include;
	}

	public static function mand( $a, $b ) {
		return $a && $b;
	}

	public static function request_results() {

		global $wpdb;

		$parameters = self::get_request_parameters();
		extract( $parameters );

		$thumbnails = self::DEFAULT_THUMBNAILS; 

		$cache_key = self::get_cache_key( array(
			'title'        => $title,
			'excerpt'      => $excerpt,
			'content'      => $content,
			'limit'        => $numberposts,
			'order'        => $order,
			'order_by'     => $order_by,
			'search_query' => $search_query,
			'thumbnails'   => $thumbnails
		) );

		$search_terms = explode( ' ', $search_query );

		$results = wp_cache_get( $cache_key, self::RESULT_CACHE_GROUP, true );
		if ( $results !== false ) {
			return $results;
		}

		$include = self::get_post_ids_for_request();

		$options = AP_Search_Live::get_options();
		
		$description_length = AP_Search_Live::DESCRIPTION_LENGTH_DEFAULT;
		$results = array();
		$post_ids = array();

		$instance = get_option('widget_ap_search_live_widget') ;
		print_r(unserialize($instance));

		if ( count( $include ) > 0) {
			$post_types = array('post');
			
			$query_args = array(
				'fields'      => 'ids',
				'post_type'   => $post_types,
				'post_status' => array( 'publish' ),
				'numberposts' => $numberposts, 
				'include'     => $include,
				'order'       => $order,
				'orderby'     => $order_by,
				'suppress_filters' => 0
			);
			
			
			$posts = get_posts( $query_args );
			$i = 0; 
			foreach( $posts as $post ) {

				if ( $post = get_post( $post ) ) {

					$post_ids[] = $post->ID;

					$thumbnail_url = null;
					$thumbnail_alt = null;

					if ( $thumbnail_id = get_post_thumbnail_id( $post->ID ) ) {

						if ( $image = wp_get_attachment_image_src( $thumbnail_id, AP_Search_Live_Thumbnail::thumbnail_size_name(), false ) ) {
							$thumbnail_url    = $image[0];
							$thumbnail_width  = $image[1];
							$thumbnail_height = $image[2];

							$thumbnail_alt = trim( strip_tags( get_post_meta( $thumbnail_id, '_wp_attachment_image_alt', true ) ) );
							
							if ( empty( $thumbnail_alt ) ) 
								$thumbnail_alt = $post->post_title ;
						}
					}

					if ( $thumbnail_url === null ) {
						$placeholder = AP_Search_Live_Thumbnail::get_placeholder_thumbnail();
						if ( $placeholder !== null ) {
							list( $thumbnail_url, $thumbnail_width, $thumbnail_height ) = $placeholder;
							$thumbnail_alt = __( 'Placeholder Image', 'ap-search-live' );
						}
					}

					$description = '';
					if ( !empty( $post->post_excerpt ) ) {
						$content = self::flatten( apply_filters( 'get_the_excerpt', $post->post_excerpt ) );
						$description = wp_trim_words( $content, $description_length, ' &hellip;' );
					}
					if ( empty( $description ) ) {
						$content = $post->post_content;
						$content = apply_filters( 'the_content', $content );
						$content = str_replace( ']]>', ']]&gt;', $content );
						$content = self::flatten( $content );
						$description = wp_trim_words( $content, $description_length, ' &hellip;' );
					}

					$results[$post->ID] = array(
						'id'          => $post->ID,
						'result_type' => 'post',
						'type'        => $post->post_type,
						'url'         => get_permalink( $post->ID ),
						'title'       => get_the_title( $post ),
						'description' => $description,
						'category'	  => get_the_category($post->ID ),
						'custom_fields'=> get_post_custom($post->ID ),
						'i'           => $i,
						'thumbnail'   => $thumbnail_url,
						'thumbnail_width' => $thumbnail_width,
						'thumbnail_height' => $thumbnail_height
					);
					if ( !empty( $thumbnail_alt ) ) {
							$results[$post->ID]['thumbnail_alt'] = $thumbnail_alt;
						}
					$i++;
					if ( $i >= $numberposts ) {
						break;
					}

					unset( $post );
				}
			}
			unset( $posts );
			usort( $results, array( __CLASS__, 'usort' ) );
		}
		
		$cached = wp_cache_set( $cache_key, $results, self::RESULT_CACHE_GROUP, self::get_cache_lifetime() );

		$results=self::APsearchLiveOrder($results);
		
		return $results;
	}
	
	public static function get_cache_key( $parameters ) {
		return md5( implode( '-', $parameters ) );
	}

	public static function get_cache_lifetime() {
		$l = intval( apply_filters( 'ap_search_live_cache_lifetime', self::CACHE_LIFETIME ) );
		return $l;
	}

	public static function usort( $e1, $e2 ) {
		return $e1['i'] - $e2['i'];
	}

	private static function flatten( $content ) {
		$content = str_replace( '><', '> <', $content );
		$content = wp_strip_all_tags( $content, true );
		$content = preg_replace('/\n+|\t+|\s+/', ' ', $content );
		$content = trim( $content );
		return $content;
	}

	private static function APsearchLiveOrder($results){
		$instance = get_option('widget_ap_search_live_widget') ;
		print_r(unserialize($instance));

		$index = reset($instance);
		$index=key($instance);

		if($instance[$index]['custom_order']==="CF"){
			$prova=array();
			foreach ($results as $post) { 
				$cf=$post['custom_fields']; 
				foreach ($cf as $key => $value) {
					
					if($key=== $instance[$index]['choosen_cf'] ){
						$prova[]=$post;
					}
					unset($cf);
				}
			}

			$sorted = array();
			foreach ($prova as $key => $value){

    			$sorted[ $instance[$index]['choosen_cf'] ][$key] = $value['custom_fields'][ $instance[$index]['choosen_cf'] ];
			}
			if($instance[$index]['order']===DESC){
				array_multisort($sorted[ $instance[$index]['choosen_cf'] ], SORT_DESC, $prova);
			}
			else{
				array_multisort($sorted[ $instance[$index]['choosen_cf'] ], SORT_ASC, $prova);
			}

			return $prova;
		}

		elseif($instance[$index]['custom_order']==="CAT"){
			$prova=array();
			$category_order=$instance[$index]['category_order'];
			$csort = array();
			foreach ($category_order as $key => $row)
			{
		    $csort[$key] = $row['term_order'];
			}
			array_multisort($csort, SORT_ASC, $category_order);

			foreach ($category_order as $cat) {
				$name = $cat['name'];
				foreach ($results as $post) {
					$categories=$post['category'];
					foreach ($categories as $categ) {
						if($categ->name===$name){
							$prova[]=$post;

						}
					}
				}
			}
		
			return $prova;

		}

		else{
			return $results;
		}
	}

}
AP_Search_Live_Service::init();
